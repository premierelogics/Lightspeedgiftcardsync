<?php

class Auth 
{

   public static function getToken()
   {
      $url = 'https://cloud.lightspeedapp.com/oauth/access_token.php';
      
      $postfields['client_id'] = CLIENT_ID;
      $postfields['client_secret'] = CLIENT_SECRET;
      $postfields['refresh_token'] = REFRESH_TOKEN;
      $postfields['grant_type'] = 'refresh_token';
      
      $curl = curl_init();

      curl_setopt($curl, CURLOPT_URL, $url);
      curl_setopt($curl, CURLOPT_POST, sizeof($postfields));
      curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

      $response = curl_exec($curl);
      $err = curl_error($curl);
      curl_close($curl);

      if ($err) {
          return false;
      } else {
          $res = json_decode($response, true);
          return $res['access_token'];
      }
   }
  
}
