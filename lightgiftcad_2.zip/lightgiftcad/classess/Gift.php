<?php

class Gift extends Auth
{
     

     protected $token;

    public function __construct($token){
        $this->token = $token;
    }
   

   public function create($code)
   {
        $url = 'https://api.lightspeedapp.com/API/Account/192594/CreditAccount.json';

        $data['description'] = "Gift Card";
        $data['name'] = "Gift Card ".date('Y-m-d');
        $data['code'] = $code;

        $postdata = json_encode($data);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'authorization: Bearer '. $this->token));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        
        
        $result = curl_exec($ch);
        
        curl_close($ch);
        return json_decode($result, true);
   }

   public function topUp($accountId, $amount)
   {
        $url = 'https://api.lightspeedapp.com/API/Account/192594/Sale.json';

        $data['employeeID'] = 5;
        $data['registerID'] = 1;
        $data['shopID'] = 1;
        $data['completed'] = true;
        
        //$amount = $amount/100;

        $data['SalePayments'][0]["SalePayment"] = -$amount;
        $data['SalePayments'][0]["creditAccountID"] = $accountId;
        $data['SalePayments'][0]["paymentTypeID"] = 5;

        $data['SalePayments'][1]["amount"] = $amount;
        $data['SalePayments'][1]["paymentTypeID"] = 10;

        // $postdata = json_encode($data);
        $postdata = '{"employeeID":5,"registerID":1,"shopID":1,"completed":true,"SalePayments":{"SalePayment":[{"amount":"-'.$amount.'","creditAccountID":"'.$accountId.'","paymentTypeID":5},{"amount":"'.$amount.'","paymentTypeID":"10"}]}}';

        // $headers[] = 'Content-Type: text/plain';
        $headers[] = 'authorization: Bearer '. $this->token;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
   }

   public function charge($accountId, $amount)
   {
        $url = 'https://api.lightspeedapp.com/API/Account/192594/Sale.json';

        // $postdata = json_encode($data);
        $postdata = '{"employeeID":5,"registerID":1,"shopID":1,"completed":true,"SaleLines":{"SaleLine":{"itemID":1386,"unitQuantity":'.ceil($amount).'}},"SalePayments":{"SalePayment":{"amount":"'.ceil($amount).'","creditAccountID":"'.$accountId.'","paymentTypeID":"5"}}}';

     //    $fp = fopen('json-'.time().'.json', 'w');
     //      fwrite($fp, $postdata);
     //      fclose($fp);

        // $headers[] = 'Content-Type: text/plain';
        $headers[] = 'authorization: Bearer '. $this->token;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);

     //    $fp = fopen('jsonres-'.time().'.json', 'w');
     //      fwrite($fp, $result);
     //      fclose($fp);

        curl_close($ch);
        return json_decode($result, true);
   }

}


?>