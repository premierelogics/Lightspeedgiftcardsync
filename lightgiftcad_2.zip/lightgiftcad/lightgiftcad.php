<?php
/*
Plugin Name: Light Speed Gift Card
Plugin URI: http://maxenius.com/wp/woo-woo-lcs-shipment-maker
Description: This plugin will automatically add your new order on LCS
Version: 1.0 
Author: Maxenius Solutions
Author URI: http://maxenius.com 
License: GPLv2 or later
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
error_reporting(0);

include_once "config.php";
include_once "classess/Auth.php";
include_once "classess/Gift.php";

class CHECKOUT_TRAVELER_FIELDS
{
    private $gift = null;

	public function __construct()
	{
        // Custom checkout fields validation
        // add_action( 'woocommerce_checkout_process', [$this,'custom_checkout_field_process'] );

        // Save custom checkout fields the data to the order
        add_action('woocommerce_thankyou', array($this,'genrate_topup_giftcard_lightspeed'));
	}


    function custom_checkout_field_process() {
        for($i=1; $i<=WC()->cart->get_cart_contents_count(); $i++){
            if ( isset($_POST['_trp_fname_'.$i]) && empty($_POST['_trp_fname_'.$i]) )
                wc_add_notice( '<strong> Traveler '.$i.' First Name</strong> is a required', 'error' );

            if ( isset($_POST['_trp_lname_'.$i]) && empty($_POST['_trp_lname_'.$i]) )
                wc_add_notice( '<strong> Traveler '.$i.' Last Name</strong> is a required', 'error' );
            
            if ( isset($_POST['_trp_phone_'.$i]) && empty($_POST['_trp_phone_'.$i]) )
                wc_add_notice( '<strong> Traveler '.$i.' Phone</strong> is a required', 'error' );

            if ( isset($_POST['_trp_dob_'.$i]) && empty($_POST['_trp_dob_'.$i]) )
                wc_add_notice( '<strong> Traveler '.$i.' Date of Birth</strong> is a required', 'error' );

            if ( isset($_POST['_trp_email_'.$i]) && empty($_POST['_trp_email_'.$i]) )
                wc_add_notice( '<strong> Traveler '.$i.' Email</strong> is a required', 'error' );
        }
    }


    function genrate_topup_giftcard_lightspeed( $order_id ){

        $cookie_name = "loid_".$order_id;

        if(isset($_COOKIE[$cookie_name])) return false;

        setcookie($cookie_name, $order_id, time() + (86400 * 30), "/");

        $order = wc_get_order( $order_id );

        $this->giftCardCreateTopUp($order);

        $this->giftCardCharge($order);
        
    }

    function giftCardCreateTopUp($order) {

        $order_items = $order->get_items();
        
        foreach($order_items as $item_id => $item )
        {
            $gift_code = $item->get_meta( '_ywgc_gift_card_number', true );
            $gift_id = $item->get_meta( '_ywgc_gift_card_post_id', true );

            if($gift_id){
                
                if($this->gift === null)
                    $this->gift = new Gift(Auth::getToken());

                $res = $this->gift->create($gift_code);

                $accID = $res['CreditAccount']['creditAccountID'];
                add_post_meta($gift_id, '_gift_acc_id', $accID);

                $this->gift->topUp($accID, $item->get_total());
            }
        }
    }

    function giftCardCharge($order){

        $discount = $order->get_total_discount();
        $coupons = $order->get_used_coupons();
		
		// echo '<pre>';
		

        if($discount > 0 && count($coupons) > 0){

            if($this->gift === null)
                    $this->gift = new Gift(Auth::getToken());

            foreach( $order->get_used_coupons() as $key => $item ){

                $coupon = get_page_by_title($item, OBJECT, 'gift_card');
				//print_r($item);
				//echo '<br>';

                $coupon_id = $coupon->ID;

                $acc_id = get_post_meta($coupon_id, '_gift_acc_id', true);
				
				

                $amt = $order->get_total_discount();
				//print_r($amt);
				//echo '<br>';

                if($acc_id > 0){
					$res = $this->gift->charge($acc_id, $amt);
					
					//print_r($res);
				
				}
				
                    
            }
            
        }
		//echo '</pre>';
    }

}

new CHECKOUT_TRAVELER_FIELDS();


function my_filter_plugin_updates( $value ) {
    if( isset( $value->response['yith-woocommerce-gift-cards/init.php'])) { 
       unset( $value->response['yith-woocommerce-gift-cards/init.php'] );
     }
     return $value;
}
add_filter( 'site_transient_update_plugins', 'my_filter_plugin_updates' );

